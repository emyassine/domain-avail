# Archive — 2026-11-19

Old candidate lists and CSV results from the first naming-research runs.
Kept for history; the tool does not read this directory.

New batch results are written to `../../output/`.
